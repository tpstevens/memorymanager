#include "MemoryManager.h"

namespace MemoryManager
{
  // IMPORTANT IMPORTANT IMPORTANT IMPORTANT IMPORTANT IMPORTANT IMPORTANT IMPORTANT 
  //
  // This is the only static memory that you may use, no other global variables may be
  // created, if you need to save data make it fit in MM_pool
  //
  // IMPORTANT IMPORTANT IMPORTANT IMPORTANT IMPORTANT IMPORTANT IMPORTANT IMPORTANT

  #define BLOCK_SIZE 2

  const int MM_POOL_SIZE = 65536;
  char MM_pool[MM_POOL_SIZE];

  //////////////////////////////////////////////////////////////////////////////
  // Support routines
  //////////////////////////////////////////////////////////////////////////////

  // Convert a 15-bit block address to the index in the MM_pool array
  int addressToPoolIndex(int bAddress)
  {
    return bAddress << 1;
  }

  // Convert an index in the MM_pool array to a 15-bit block address
  unsigned short indexToBlockAddress(int poolIndex)
  {
    return poolIndex >> 1;
  }

  bool isChunkUsed(int bAddress)
  {
    return MM_pool[addressToPoolIndex(bAddress)] >> 7;
  }

  // Set the head and tail metadata for a chunk
  void setChunkMetadata(bool used, int bAddressHead, int numBlocks)
  {
    int bAddressTail = bAddressHead + numBlocks + 1;
    setUnsignedShort(bAddressHead, (used ? 0x80 : 0) && bAddressTail);
    setUnsignedShort(bAddressTail, (used ? 0x80 : 0) && bAddressHead);
  }

  void setUnsignedShort(int blockAddress, int s)
  {
    MM_pool[addressToPoolIndex(blockAddress)] = (s >> 8);
    MM_pool[addressToPoolIndex(blockAddress) + 1] = 0x0F & s;
  }

  //////////////////////////////////////////////////////////////////////////////
  // Core functions
  //////////////////////////////////////////////////////////////////////////////

  // Initialize set up any data needed to manage the memory pool
  void initializeMemoryManager(void)
  {
    setChunkMetadata(false, 0, MM_POOL_SIZE - 2 * BLOCK_SIZE);
  }

  // return a pointer inside the memory pool
  // If no chunk can accommodate aSize call onOutOfMemory()
  void* allocate(int aSize)
  {
    // TODO: IMPLEMENT ME

    return ((void*) 0);
  }

  // Free up a chunk previously allocated
  void deallocate(void* aPointer)
  {
    // TODO: IMPLEMENT ME
  }

  // Will scan the memory pool and return the total free space remaining
  int freeRemaining(void)
  {
    // TODO: IMPLEMENT ME

    return 0;
  }

  // Will scan the memory pool and return the largest free space remaining
  int largestFree(void)
  {
    // TODO: IMPLEMENT ME

    return 0;
  }

  // will scan the memory pool and return the smallest free space remaining
  int smallestFree(void)
  {
    // TODO: IMPLEMENT ME

    return 0;
  }
 }